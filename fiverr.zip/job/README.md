o# Build Medley in Docker 


Step 1. Build the Build Container  
    
     docker build  -t build-medley .
 

Step 2 run the Build Container
     
     docker run -it build-medley bash
   
  

Step 3.  Build Medley

    1. open a new Terminal (beacuse the container has no CMD )
    2. docker exec -it <ContainerName>  bash -c "Xvfb :1 -screen 0 1440x900x16 &> xvfb.log & ps aux | grep X ; DISPLAY=:1.0 ; export DISPLAY ; ./scripts/loadup-all.sh "

Step 4.  Test Medley

     docker exec -it <ContainerName>  bash -c "Xvfb :1 -screen 0 1440x900x16 &> xvfb.log & ps aux | grep X ; DISPLAY=:1.0 ; export DISPLAY ; ./run-medley"

or with timeout 

    docker exec -it <ContainerName>  bash -c "Xvfb :1 -screen 0 1440x900x16 &> xvfb.log & ps aux | grep X ; DISPLAY=:1.0 ; export DISPLAY ; timeout 10s ./run-medley; exit 0"
